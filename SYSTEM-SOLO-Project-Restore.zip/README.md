# SYSTEM: SOLO — Android MVP

A local-first, Solo Leveling-inspired personal development tracker for Android. It uses ordinary Android APIs and stores player data on-device.

## Included in this first build

- Dark RPG-inspired player dashboard.
- Level and EXP progression (`100 × current level` EXP for the next level).
- Six game-style attributes: STR, AGI, VIT, INT, SEN and DIS.
- Five distributable stat points per level-up, plus one automatic point in each attribute.
- Create, complete and delete one-time, daily and weekly quests.
- Earn EXP and virtual coins for completing quests.
- Alarm/reminder manager with one-time, daily, weekdays and weekly schedules.
- Android notification with the system alarm sound when an alarm fires.
- Repeating-alarm rescheduling after delivery and after device reboot.
- Skills, class selection, achievements-by-milestone, virtual inventory and reward shop.
- Local persistence using SharedPreferences/JSON; no account or server is required.

## Requirements

- Android 8.0 (API 26) or later.
- Build with JDK 17, Gradle 8.13, Android Gradle Plugin 8.13.2, Android SDK platform 35.
- The included GitHub Actions workflow builds a debug APK without a local Android SDK.

## Build with GitHub Actions

1. Create a repository on GitHub.
2. Upload the contents of this project to the repository root (not the parent folder).
3. Open the **Actions** tab and enable workflows if GitHub asks.
4. Select **Build SYSTEM SOLO APK** and choose **Run workflow**, or push a commit to `main`/`master`.
5. When the workflow succeeds, open that run and download the `SYSTEM-SOLO-debug-APK` artifact.
6. Extract the artifact ZIP on your phone and install `SYSTEM-SOLO-debug.apk`.

The workflow is in `.github/workflows/android.yml`.

## Alarm permissions on Android 14

On first launch, allow notifications. For close-to-exact alarm delivery, open the app's **Alarms & reminders** setting and enable access for SYSTEM: SOLO. Android 12+ requires special access for exact alarms. If exact-alarm access is not granted, the app schedules an inexact fallback instead.

The app creates a notification channel named **Quest alarms**. Its sound is controlled by Android's notification-channel settings. Check that the channel is not silent, notification volume is audible, and Do Not Disturb is configured appropriately.

## Important limitations of this MVP

- This is a debug APK, not a Play Store release. It is intended for personal testing.
- The alarm uses Android's alarm/notification system. Do Not Disturb, disabled notification permission, silent channel settings, OEM battery controls, or a powered-off phone can affect alerts. The app does not assume a physical notification LED exists; visual flash alerts depend on Android accessibility settings and the device.
- A one-time reminder selected with a time picker is scheduled for the next occurrence of that time (today if still ahead, otherwise tomorrow).
- Weekly reminders repeat on the weekday on which they were created.
- Attribute values are game scores, not medical, fitness or IQ measurements.
- Coins and shop items are virtual only and have no cash value.
- There is no cloud sync yet. Keep a backup before uninstalling or clearing app data.

## Package details

- Application ID: `com.arman.systemsolo`
- App label: `SYSTEM: SOLO`
- Version: `1.0.0`
- Minimum Android: API 26
- Target Android: API 34

## Privacy

No analytics, ads, login, network permissions or third-party SDKs are included. Android app backup is disabled; player and quest data remain in the app's private local storage.
