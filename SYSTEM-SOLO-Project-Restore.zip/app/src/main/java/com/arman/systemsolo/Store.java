package com.arman.systemsolo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class Store {
    private static final String PREF = "system_solo_data";
    private Store() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static void initialise(Context c) {
        SharedPreferences p = p(c);
        if (!p.contains("level")) {
            p.edit().putInt("level", 1).putInt("xp", 0).putInt("coins", 0)
                    .putInt("stat_points", 0).putInt("total_completed", 0)
                    .putString("player_name", "PLAYER")
                    .putString("player_class", "Unassigned")
                    .putString("inventory", "[]")
                    .putInt("stat_STR", 5).putInt("stat_AGI", 5)
                    .putInt("stat_VIT", 5).putInt("stat_INT", 5)
                    .putInt("stat_SEN", 5).putInt("stat_DIS", 5).apply();
        }
        if (!p.contains("quests")) p.edit().putString("quests", "[]").apply();
        if (!p.contains("alarms")) p.edit().putString("alarms", "[]").apply();
        if (!p.contains("next_alarm_id")) p.edit().putInt("next_alarm_id", 1).apply();
    }

    public static int getInt(Context c, String key, int fallback) { return p(c).getInt(key, fallback); }
    public static void putInt(Context c, String key, int value) { p(c).edit().putInt(key, value).apply(); }
    public static String getString(Context c, String key, String fallback) { return p(c).getString(key, fallback); }
    public static void putString(Context c, String key, String value) { p(c).edit().putString(key, value).apply(); }

    public static JSONArray readArray(Context c, String key) {
        try { return new JSONArray(p(c).getString(key, "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }

    public static void saveArray(Context c, String key, JSONArray value) {
        p(c).edit().putString(key, value.toString()).apply();
    }

    public static JSONArray quests(Context c) { return readArray(c, "quests"); }
    public static JSONArray alarms(Context c) { return readArray(c, "alarms"); }
    public static void saveQuests(Context c, JSONArray a) { saveArray(c, "quests", a); }
    public static void saveAlarms(Context c, JSONArray a) { saveArray(c, "alarms", a); }

    public static JSONObject findAlarm(Context c, int id) {
        JSONArray a = alarms(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optInt("id") == id) return o;
        }
        return null;
    }

    public static void updateAlarm(Context c, JSONObject updated) {
        JSONArray a = alarms(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optInt("id") == updated.optInt("id")) {
                a.put(i, updated);
                saveAlarms(c, a);
                return;
            }
        }
    }

    public static void addXp(Context c, int amount) {
        int level = getInt(c, "level", 1);
        int xp = getInt(c, "xp", 0) + Math.max(0, amount);
        int points = getInt(c, "stat_points", 0);
        while (xp >= 100 * level) {
            xp -= 100 * level;
            level++;
            points += 5;
            for (String s : new String[]{"STR", "AGI", "VIT", "INT", "SEN", "DIS"}) {
                p(c).edit().putInt("stat_" + s, getInt(c, "stat_" + s, 5) + 1).apply();
            }
        }
        p(c).edit().putInt("level", level).putInt("xp", xp).putInt("stat_points", points).apply();
    }

    public static boolean isQuestDoneNow(JSONObject q) {
        long last = q.optLong("lastDone", 0L);
        if (last == 0L) return false;
        String repeat = q.optString("repeat", "ONCE");
        if ("ONCE".equals(repeat)) return true;
        java.util.Calendar a = java.util.Calendar.getInstance();
        java.util.Calendar b = java.util.Calendar.getInstance();
        b.setTimeInMillis(last);
        if ("DAILY".equals(repeat)) {
            return a.get(java.util.Calendar.YEAR) == b.get(java.util.Calendar.YEAR)
                    && a.get(java.util.Calendar.DAY_OF_YEAR) == b.get(java.util.Calendar.DAY_OF_YEAR);
        }
        return a.get(java.util.Calendar.YEAR) == b.get(java.util.Calendar.YEAR)
                && a.get(java.util.Calendar.WEEK_OF_YEAR) == b.get(java.util.Calendar.WEEK_OF_YEAR);
    }
}
