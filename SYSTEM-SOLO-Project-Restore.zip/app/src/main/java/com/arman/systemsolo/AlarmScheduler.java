package com.arman.systemsolo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public final class AlarmScheduler {
    private AlarmScheduler() {}

    public static long calculateNext(int hour, int minute, String repeat) {
        return calculateNext(hour, minute, repeat, Calendar.getInstance().get(Calendar.DAY_OF_WEEK));
    }

    public static long calculateNext(int hour, int minute, String repeat, int weekday) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long now = System.currentTimeMillis();
        if ("WEEKLY".equals(repeat)) {
            while (c.get(Calendar.DAY_OF_WEEK) != weekday || c.getTimeInMillis() <= now) {
                c.add(Calendar.DAY_OF_YEAR, 1);
            }
        } else {
            if (c.getTimeInMillis() <= now) c.add(Calendar.DAY_OF_YEAR, 1);
            if ("WEEKDAYS".equals(repeat)) {
                while (c.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || c.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
                    c.add(Calendar.DAY_OF_YEAR, 1);
                }
            }
        }
        return c.getTimeInMillis();
    }

    private static PendingIntent pendingIntent(Context context, int id) {
        Intent i = new Intent(context, AlarmReceiver.class);
        i.setAction("com.arman.systemsolo.ALARM." + id);
        i.setData(Uri.parse("systemsolo://alarm/" + id));
        i.putExtra("alarm_id", id);
        return PendingIntent.getBroadcast(context, id, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context context, JSONObject alarm) {
        if (alarm == null || !alarm.optBoolean("enabled", true)) return;
        int id = alarm.optInt("id", -1);
        if (id < 0) return;
        long at = alarm.optLong("nextAt", 0L);
        if ("ONCE".equals(alarm.optString("repeat", "ONCE")) && at <= System.currentTimeMillis()) {
            at = calculateNext(alarm.optInt("hour"), alarm.optInt("minute"), "ONCE");
            try { alarm.put("nextAt", at); } catch (org.json.JSONException ignored) {}
            Store.updateAlarm(context, alarm);
        } else if (!"ONCE".equals(alarm.optString("repeat", "ONCE")) && at <= System.currentTimeMillis()) {
            at = calculateNext(alarm.optInt("hour"), alarm.optInt("minute"), alarm.optString("repeat"), alarm.optInt("weekday", Calendar.getInstance().get(Calendar.DAY_OF_WEEK)));
            try { alarm.put("nextAt", at); } catch (org.json.JSONException ignored) {}
            Store.updateAlarm(context, alarm);
        }

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pendingIntent(context, id);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                Intent show = new Intent(context, MainActivity.class);
                PendingIntent showPi = PendingIntent.getActivity(context, 900000 + id, show,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(at, showPi);
                manager.setAlarmClock(info, pi);
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    public static void cancel(Context context, int id) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.cancel(pendingIntent(context, id));
    }

    public static void rescheduleRepeating(Context context, JSONObject alarm) {
        String repeat = alarm.optString("repeat", "ONCE");
        if ("ONCE".equals(repeat)) {
            try { alarm.put("enabled", false); } catch (org.json.JSONException ignored) {}
            Store.updateAlarm(context, alarm);
            return;
        }
        long next = calculateNext(alarm.optInt("hour"), alarm.optInt("minute"), repeat, alarm.optInt("weekday", Calendar.getInstance().get(Calendar.DAY_OF_WEEK)));
        try { alarm.put("nextAt", next); } catch (org.json.JSONException ignored) {}
        Store.updateAlarm(context, alarm);
        schedule(context, alarm);
    }

    public static void rescheduleAll(Context context) {
        JSONArray a = Store.alarms(context);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optBoolean("enabled", true)) schedule(context, o);
        }
    }
}
