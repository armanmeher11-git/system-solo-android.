package com.arman.systemsolo;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = 0xFF080B14;
    private static final int PANEL = 0xFF111827;
    private static final int CARD = 0xFF172033;
    private static final int CARD_2 = 0xFF1D2940;
    private static final int PURPLE = 0xFF9B8CFF;
    private static final int CYAN = 0xFF67E8F9;
    private static final int WHITE = 0xFFF8FAFC;
    private static final int MUTED = 0xFF9AA8BD;
    private static final int GREEN = 0xFF4ADE80;
    private static final int RED = 0xFFFB7185;

    private LinearLayout root;
    private LinearLayout content;
    private String screen = "HOME";
    private final String[] statCodes = {"STR", "AGI", "VIT", "INT", "SEN", "DIS"};
    private final String[] statNames = {"Strength", "Agility", "Vitality", "Intelligence", "Sense", "Discipline"};
    private final String[] statDescriptions = {
            "Physical training record", "Coordination and movement", "Endurance and recovery",
            "Learning and problem-solving", "Attention and observation", "Consistency and follow-through"
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Store.initialise(this);
        AlarmReceiver.createChannel(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        requestNotificationPermissionIfNeeded();
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am.canScheduleExactAlarms()) AlarmScheduler.rescheduleAll(this);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 501 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "System notifications enabled", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = column();
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackground(shape(CARD, 18, 0xFF27344C, 1));
        return l;
    }

    private void gap(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void line(LinearLayout parent) {
        View v = new View(this);
        v.setBackgroundColor(0xFF29364B);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
        p.topMargin = dp(10); p.bottomMargin = dp(10);
        parent.addView(v, p);
    }

    private Button button(String label, int fill, int textColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setMinHeight(dp(42));
        b.setBackground(shape(fill, 12, fill, 0));
        return b;
    }

    private void addTitle(LinearLayout parent, String title, String subtitle) {
        parent.addView(text(title, 22, WHITE, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = text(subtitle, 12, MUTED, false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.topMargin = dp(3);
            parent.addView(s, p);
        }
        gap(parent, 14);
    }

    private void render() {
        root = column();
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = row();
        header.setPadding(dp(18), dp(14), dp(18), dp(12));
        LinearLayout brand = column();
        TextView name = text("SYSTEM: SOLO", 18, WHITE, true);
        name.setLetterSpacing(0.08f);
        brand.addView(name);
        TextView subtitle = text("PLAYER DEVELOPMENT INTERFACE", 9, CYAN, true);
        subtitle.setLetterSpacing(0.13f);
        brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView status = text("● ONLINE", 10, GREEN, true);
        header.addView(status);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = column();
        content.setPadding(dp(16), dp(6), dp(16), dp(18));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        if ("HOME".equals(screen)) buildHome();
        else if ("QUESTS".equals(screen)) buildQuests();
        else if ("ALARMS".equals(screen)) buildAlarms();
        else if ("GROWTH".equals(screen)) buildGrowth();
        else buildHome();

        buildNavigation();
    }

    private void buildNavigation() {
        LinearLayout nav = row();
        nav.setPadding(dp(8), dp(7), dp(8), dp(8));
        nav.setBackgroundColor(PANEL);
        String[][] items = {{"HOME", "⌂"}, {"QUESTS", "☷"}, {"ALARMS", "◷"}, {"GROWTH", "✦"}};
        for (String[] item : items) {
            final String target = item[0];
            LinearLayout tab = column();
            tab.setGravity(Gravity.CENTER);
            TextView icon = text(item[1], 20, screen.equals(target) ? CYAN : MUTED, true);
            icon.setGravity(Gravity.CENTER);
            TextView label = text(target, 9, screen.equals(target) ? WHITE : MUTED, true);
            label.setGravity(Gravity.CENTER);
            tab.addView(icon);
            tab.addView(label);
            tab.setPadding(dp(4), dp(3), dp(4), dp(3));
            tab.setOnClickListener(v -> { screen = target; render(); });
            nav.addView(tab, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(nav);
    }

    private void buildHome() {
        String player = Store.getString(this, "player_name", "PLAYER");
        int level = Store.getInt(this, "level", 1);
        int xp = Store.getInt(this, "xp", 0);
        int need = 100 * level;
        int points = Store.getInt(this, "stat_points", 0);
        int coins = Store.getInt(this, "coins", 0);

        LinearLayout hero = card();
        hero.setBackground(shape(0xFF17243A, 20, 0xFF51608A, 1));
        LinearLayout top = row();
        LinearLayout who = column();
        who.addView(text("PLAYER STATUS", 10, CYAN, true));
        who.addView(text(player, 23, WHITE, true));
        who.addView(text("Hunter profile • Level " + level, 12, MUTED, false));
        top.addView(who, new LinearLayout.LayoutParams(0, -2, 1));
        TextView lvl = text("LV.\n" + level, 19, WHITE, true);
        lvl.setGravity(Gravity.CENTER);
        lvl.setBackground(shape(0xFF2B3655, 16, 0xFF7785B5, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(70), dp(70));
        top.addView(lvl, lp);
        hero.addView(top);
        gap(hero, 18);
        LinearLayout progressRow = row();
        progressRow.addView(text("EXPERIENCE", 10, MUTED, true), new LinearLayout.LayoutParams(0, -2, 1));
        progressRow.addView(text(xp + " / " + need + " XP", 12, CYAN, true));
        hero.addView(progressRow);
        gap(hero, 7);
        android.widget.ProgressBar progress = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(need); progress.setProgress(xp);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF303C52));
        hero.addView(progress, new LinearLayout.LayoutParams(-1, dp(8)));
        gap(hero, 14);
        LinearLayout stats = row();
        stats.addView(metric("STAT POINTS", String.valueOf(points)), new LinearLayout.LayoutParams(0, -2, 1));
        stats.addView(metric("COINS", String.valueOf(coins)), new LinearLayout.LayoutParams(0, -2, 1));
        stats.addView(metric("COMPLETED", String.valueOf(Store.getInt(this, "total_completed", 0))), new LinearLayout.LayoutParams(0, -2, 1));
        hero.addView(stats);
        content.addView(hero);

        gap(content, 18);
        LinearLayout titleRow = row();
        titleRow.addView(text("ATTRIBUTES", 14, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        titleRow.addView(text("GAME STATS • TAP + TO SPEND", 9, MUTED, true));
        content.addView(titleRow);
        gap(content, 8);
        LinearLayout attributes = card();
        for (int i = 0; i < statCodes.length; i++) {
            final String code = statCodes[i];
            LinearLayout r = row();
            LinearLayout details = column();
            details.addView(text(code + "  •  " + statNames[i], 13, WHITE, true));
            details.addView(text(statDescriptions[i], 10, MUTED, false));
            r.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
            r.addView(text(String.valueOf(Store.getInt(this, "stat_" + code, 5)), 18, CYAN, true));
            Button plus = button("+", 0xFF34305D, WHITE);
            plus.setMinWidth(dp(44));
            plus.setEnabled(points > 0);
            plus.setAlpha(points > 0 ? 1f : 0.45f);
            plus.setOnClickListener(v -> spendPoint(code));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(46), dp(40));
            bp.leftMargin = dp(12);
            r.addView(plus, bp);
            attributes.addView(r);
            if (i != statCodes.length - 1) line(attributes);
        }
        content.addView(attributes);

        gap(content, 18);
        LinearLayout quick = row();
        quick.addView(text("QUICK ACCESS", 14, WHITE, true), new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(quick);
        gap(content, 8);
        LinearLayout actions = row();
        Button q = button("+ NEW QUEST", 0xFF443A83, WHITE);
        q.setOnClickListener(v -> showQuestDialog());
        actions.addView(q, new LinearLayout.LayoutParams(0, -2, 1));
        Button a = button("+ ALARM", 0xFF17485A, WHITE);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, -2, 1);
        ap.leftMargin = dp(8);
        a.setOnClickListener(v -> showAlarmDialog());
        actions.addView(a, ap);
        content.addView(actions);

        gap(content, 18);
        content.addView(text("TODAY'S QUESTS", 14, WHITE, true));
        gap(content, 8);
        JSONArray quests = Store.quests(this);
        int shown = 0;
        for (int i = 0; i < quests.length() && shown < 3; i++) {
            JSONObject obj = quests.optJSONObject(i);
            if (obj == null) continue;
            addQuestCard(content, obj, true);
            shown++;
        }
        if (shown == 0) {
            LinearLayout empty = card();
            empty.addView(text("No quests yet. Create your first quest to start earning EXP.", 12, MUTED, false));
            content.addView(empty);
        }
    }

    private LinearLayout metric(String name, String value) {
        LinearLayout l = column();
        l.addView(text(name, 8, MUTED, true));
        l.addView(text(value, 15, WHITE, true));
        return l;
    }

    private void buildQuests() {
        addTitle(content, "QUEST BOARD", "Create real-world challenges. Complete them to earn EXP and coins.");
        Button add = button("＋  CREATE QUEST", 0xFF443A83, WHITE);
        add.setOnClickListener(v -> showQuestDialog());
        content.addView(add);
        gap(content, 12);
        JSONArray quests = Store.quests(this);
        if (quests.length() == 0) {
            LinearLayout empty = card();
            empty.addView(text("The board is empty.", 16, WHITE, true));
            empty.addView(text("Add a study, skill, fitness or personal-development quest.", 12, MUTED, false));
            content.addView(empty);
        }
        for (int i = 0; i < quests.length(); i++) {
            JSONObject q = quests.optJSONObject(i);
            if (q != null) addQuestCard(content, q, false);
        }
    }

    private void addQuestCard(LinearLayout parent, JSONObject q, boolean compact) {
        LinearLayout c = card();
        String title = q.optString("title", "Untitled quest");
        String repeat = q.optString("repeat", "ONCE");
        int xp = q.optInt("xp", 10);
        boolean done = Store.isQuestDoneNow(q);
        LinearLayout top = row();
        TextView heading = text(title, compact ? 13 : 15, WHITE, true);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(text(done ? "✓ DONE" : "+" + xp + " XP", 10, done ? GREEN : CYAN, true));
        c.addView(top);
        TextView sub = text(repeat + " • " + (done ? "Completed for this period" : "Ready for completion"), 10, MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5);
        c.addView(sub, sp);
        if (!compact) {
            gap(c, 10);
            LinearLayout buttons = row();
            Button complete = button(done ? "COMPLETED" : "COMPLETE QUEST", done ? 0xFF254435 : 0xFF164A44, WHITE);
            complete.setEnabled(!done);
            complete.setOnClickListener(v -> completeQuest(q.optInt("id")));
            buttons.addView(complete, new LinearLayout.LayoutParams(0, -2, 1));
            Button delete = button("DELETE", 0xFF542D3A, WHITE);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
            dp.leftMargin = dp(8);
            delete.setOnClickListener(v -> deleteQuest(q.optInt("id")));
            buttons.addView(delete, dp);
            c.addView(buttons);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(9);
        parent.addView(c, p);
    }

    private void showQuestDialog() {
        LinearLayout form = column();
        form.setPadding(dp(18), dp(8), dp(18), dp(4));
        EditText title = edit("Quest name");
        EditText xp = edit("EXP reward (e.g. 20)");
        xp.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        Spinner repeat = new Spinner(this);
        String[] choices = {"One-time", "Daily", "Weekly"};
        repeat.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices));
        CheckBox reminder = new CheckBox(this);
        reminder.setText("Set a phone reminder for this quest");
        reminder.setTextColor(WHITE);
        form.addView(title); gap(form, 8); form.addView(xp); gap(form, 8); form.addView(repeat); gap(form, 6); form.addView(reminder);
        new AlertDialog.Builder(this).setTitle("Create quest").setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Create", (d, w) -> {
                    String t = title.getText().toString().trim();
                    if (t.isEmpty()) { toast("Enter a quest name"); return; }
                    int reward = 20;
                    try { reward = Integer.parseInt(xp.getText().toString().trim()); } catch (Exception ignored) {}
                    reward = Math.max(1, Math.min(500, reward));
                    String mode = repeat.getSelectedItemPosition() == 1 ? "DAILY" : repeat.getSelectedItemPosition() == 2 ? "WEEKLY" : "ONCE";
                    int id = (int) (System.currentTimeMillis() & 0x7fffffff);
                    JSONObject q = new JSONObject();
                    try {
                        q.put("id", id); q.put("title", t); q.put("xp", reward); q.put("repeat", mode);
                        q.put("lastDone", 0L); q.put("createdAt", System.currentTimeMillis());
                    } catch (JSONException ignored) {}
                    JSONArray all = Store.quests(this); all.put(q); Store.saveQuests(this, all);
                    if (reminder.isChecked()) {
                        final String questName = t;
                        final String alarmRepeat = mode;
                        new TimePickerDialog(this, (view, hour, minute) -> createAlarm(questName, hour, minute, alarmRepeat),
                                17, 0, false).show();
                    }
                    screen = "QUESTS"; render();
                }).show();
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(WHITE);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackground(shape(CARD_2, 10, 0xFF3A4963, 1));
        return e;
    }

    private void completeQuest(int id) {
        JSONArray all = Store.quests(this);
        for (int i = 0; i < all.length(); i++) {
            JSONObject q = all.optJSONObject(i);
            if (q == null || q.optInt("id") != id) continue;
            if (Store.isQuestDoneNow(q)) { toast("Quest already completed for this period"); return; }
            try { q.put("lastDone", System.currentTimeMillis()); all.put(i, q); } catch (JSONException ignored) {}
            Store.saveQuests(this, all);
            int reward = q.optInt("xp", 10);
            Store.addXp(this, reward);
            Store.putInt(this, "coins", Store.getInt(this, "coins", 0) + Math.max(1, reward / 5));
            Store.putInt(this, "total_completed", Store.getInt(this, "total_completed", 0) + 1);
            toast("Quest completed • +" + reward + " XP");
            render();
            return;
        }
    }

    private void deleteQuest(int id) {
        new AlertDialog.Builder(this).setTitle("Delete quest?").setMessage("This removes the quest from your board.")
                .setNegativeButton("Cancel", null).setPositiveButton("Delete", (d, w) -> {
                    JSONArray old = Store.quests(this), next = new JSONArray();
                    for (int i = 0; i < old.length(); i++) {
                        JSONObject q = old.optJSONObject(i);
                        if (q != null && q.optInt("id") != id) next.put(q);
                    }
                    Store.saveQuests(this, next); render();
                }).show();
    }

    private void buildAlarms() {
        addTitle(content, "ALARM MANAGER", "Schedule audible reminders. Alarms can ring while the app is closed.");
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || ((AlarmManager) getSystemService(ALARM_SERVICE)).canScheduleExactAlarms();
        LinearLayout access = card();
        access.addView(text(exact ? "EXACT ALARM ACCESS  •  ENABLED" : "EXACT ALARM ACCESS  •  NOT GRANTED", 11, exact ? GREEN : RED, true));
        TextView info = text(exact ? "Your reminders can use Android's exact alarm API." : "Android may use less precise reminders until you allow Alarms & reminders access.", 11, MUTED, false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(5); access.addView(info, ip);
        if (!exact) {
            Button grant = button("OPEN ALARMS & REMINDERS SETTINGS", 0xFF443A83, WHITE);
            LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(10);
            grant.setOnClickListener(v -> requestExactAlarmAccess()); access.addView(grant, gp);
        }
        content.addView(access);
        gap(content, 12);
        Button add = button("＋  ADD ALARM", 0xFF17485A, WHITE);
        add.setOnClickListener(v -> showAlarmDialog()); content.addView(add);
        gap(content, 12);
        content.addView(text("SCHEDULED REMINDERS", 13, WHITE, true)); gap(content, 8);
        JSONArray alarms = Store.alarms(this);
        if (alarms.length() == 0) {
            LinearLayout empty = card(); empty.addView(text("No alarms scheduled.", 14, WHITE, true));
            empty.addView(text("Create a reminder and test it with a time a few minutes from now.", 11, MUTED, false)); content.addView(empty);
        }
        for (int i = 0; i < alarms.length(); i++) {
            JSONObject a = alarms.optJSONObject(i);
            if (a == null) continue;
            LinearLayout c = card();
            LinearLayout r = row();
            LinearLayout details = column();
            details.addView(text(a.optString("title", "Reminder"), 14, WHITE, true));
            String time = String.format(Locale.getDefault(), "%02d:%02d", a.optInt("hour"), a.optInt("minute"));
            details.addView(text(time + " • " + a.optString("repeat", "ONCE"), 11, MUTED, false));
            r.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
            Button toggle = button(a.optBoolean("enabled", true) ? "ON" : "OFF", a.optBoolean("enabled", true) ? 0xFF164A44 : 0xFF3A4354, WHITE);
            toggle.setOnClickListener(v -> toggleAlarm(a.optInt("id")));
            r.addView(toggle);
            Button del = button("×", 0xFF542D3A, WHITE);
            LinearLayout.LayoutParams delp = new LinearLayout.LayoutParams(dp(44), dp(42)); delp.leftMargin = dp(6);
            del.setOnClickListener(v -> deleteAlarm(a.optInt("id"))); r.addView(del, delp);
            c.addView(r);
            if (a.optBoolean("enabled", true)) {
                TextView next = text("Next: " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(a.optLong("nextAt")), 10, CYAN, false);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(8); c.addView(next, np);
            }
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.bottomMargin = dp(9); content.addView(c, cp);
        }
        gap(content, 6);
        TextView note = text("Reminder sound follows the phone's notification-channel settings. Silent mode, Do Not Disturb, notification permission and battery restrictions can affect sound or delivery.", 10, MUTED, false);
        content.addView(note);
    }

    private void showAlarmDialog() {
        LinearLayout form = column(); form.setPadding(dp(18), dp(8), dp(18), dp(4));
        EditText title = edit("Reminder title");
        Spinner repeat = new Spinner(this);
        String[] options = {"Once", "Every day", "Weekdays (Mon–Fri)", "Weekly (same day)"};
        repeat.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, options));
        form.addView(title); gap(form, 10); form.addView(text("Repeat", 12, MUTED, true)); form.addView(repeat);
        new AlertDialog.Builder(this).setTitle("New reminder").setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Choose time", (d, w) -> {
                    String t = title.getText().toString().trim();
                    if (t.isEmpty()) t = "Quest reminder";
                    String mode = repeat.getSelectedItemPosition() == 1 ? "DAILY" : repeat.getSelectedItemPosition() == 2 ? "WEEKDAYS" : repeat.getSelectedItemPosition() == 3 ? "WEEKLY" : "ONCE";
                    final String savedTitle = t; final String savedMode = mode;
                    Calendar now = Calendar.getInstance();
                    new TimePickerDialog(this, (view, hour, minute) -> createAlarm(savedTitle, hour, minute, savedMode),
                            now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
                }).show();
    }

    private void createAlarm(String title, int hour, int minute, String repeat) {
        int id = Store.getInt(this, "next_alarm_id", 1);
        Store.putInt(this, "next_alarm_id", id + 1);
        JSONObject a = new JSONObject();
        long next = AlarmScheduler.calculateNext(hour, minute, repeat);
        try {
            a.put("id", id); a.put("title", title); a.put("hour", hour); a.put("minute", minute);
            a.put("repeat", repeat); a.put("enabled", true); a.put("nextAt", next);
            a.put("weekday", Calendar.getInstance().get(Calendar.DAY_OF_WEEK));
            JSONArray all = Store.alarms(this); all.put(a); Store.saveAlarms(this, all);
        } catch (JSONException ignored) {}
        AlarmScheduler.schedule(this, a);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !((AlarmManager) getSystemService(ALARM_SERVICE)).canScheduleExactAlarms()) {
            new AlertDialog.Builder(this).setTitle("Allow exact alarms")
                    .setMessage("To ring close to the exact time, allow SYSTEM: SOLO under Settings → Alarms & reminders. Without this access Android may deliver the reminder later.")
                    .setNegativeButton("Not now", (d, w) -> { screen = "ALARMS"; render(); })
                    .setPositiveButton("Open settings", (d, w) -> requestExactAlarmAccess()).show();
        }
        screen = "ALARMS"; render();
        toast("Reminder saved");
    }

    private void requestExactAlarmAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
                try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
                catch (Exception ignored) { toast("Open App info → Alarms & reminders manually"); }
            }
        }
    }

    private void toggleAlarm(int id) {
        JSONObject a = Store.findAlarm(this, id);
        if (a == null) return;
        boolean enabled = !a.optBoolean("enabled", true);
        try { a.put("enabled", enabled); } catch (JSONException ignored) {}
        Store.updateAlarm(this, a);
        if (enabled) {
            if (a.optLong("nextAt") <= System.currentTimeMillis()) {
                try { a.put("nextAt", AlarmScheduler.calculateNext(a.optInt("hour"), a.optInt("minute"), a.optString("repeat"), a.optInt("weekday", Calendar.getInstance().get(Calendar.DAY_OF_WEEK)))); } catch (JSONException ignored) {}
                Store.updateAlarm(this, a);
            }
            AlarmScheduler.schedule(this, a);
        } else AlarmScheduler.cancel(this, id);
        render();
    }

    private void deleteAlarm(int id) {
        AlarmScheduler.cancel(this, id);
        JSONArray old = Store.alarms(this), next = new JSONArray();
        for (int i = 0; i < old.length(); i++) {
            JSONObject a = old.optJSONObject(i);
            if (a != null && a.optInt("id") != id) next.put(a);
        }
        Store.saveAlarms(this, next); render(); toast("Reminder deleted");
    }

    private void buildGrowth() {
        addTitle(content, "GROWTH & REWARDS", "Skills, classes, achievements and your virtual inventory.");
        int level = Store.getInt(this, "level", 1);
        String playerClass = Store.getString(this, "player_class", "Unassigned");
        LinearLayout cl = card();
        cl.addView(text("CURRENT CLASS", 10, CYAN, true)); gap(cl, 4);
        cl.addView(text(playerClass, 20, WHITE, true));
        cl.addView(text(level >= 3 ? "Your specialisation can be changed." : "Reach Level 3 to choose a class.", 11, MUTED, false));
        Button choose = button("CHOOSE CLASS", 0xFF443A83, WHITE);
        choose.setEnabled(level >= 3); choose.setAlpha(level >= 3 ? 1f : 0.5f);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(10); choose.setOnClickListener(v -> chooseClass()); cl.addView(choose, cp);
        content.addView(cl);

        gap(content, 16); content.addView(text("UNLOCKABLE SKILLS", 14, WHITE, true)); gap(content, 8);
        int completed = Store.getInt(this, "total_completed", 0);
        addSkillCard("FAST LEARNER", "Complete 5 quests", completed >= 5, "A record of consistent learning practice.");
        addSkillCard("PROBLEM SOLVER", "Complete 15 quests", completed >= 15, "A milestone for sustained problem-solving work.");
        addSkillCard("COMMUNICATOR", "Complete 25 quests", completed >= 25, "A milestone for communication practice.");
        addSkillCard("FIELD VETERAN", "Complete 50 quests", completed >= 50, "A milestone for long-term consistency.");

        gap(content, 16); content.addView(text("INVENTORY", 14, WHITE, true)); gap(content, 8);
        JSONArray inventory = Store.readArray(this, "inventory");
        LinearLayout inv = card();
        if (inventory.length() == 0) inv.addView(text("Your inventory is empty. Earn coins and visit the shop.", 11, MUTED, false));
        else for (int i = 0; i < inventory.length(); i++) inv.addView(text("◆  " + inventory.optString(i), 12, CYAN, true));
        content.addView(inv);

        gap(content, 16); content.addView(text("REWARD SHOP", 14, WHITE, true)); gap(content, 8);
        addShopItem("Night Runner title", "A profile title", 50);
        addShopItem("Shadow Scholar title", "A profile title", 100);
        addShopItem("Elite Hunter title", "A profile title", 200);
        TextView caution = text("Coins are virtual rewards with no cash value.", 10, MUTED, false); content.addView(caution);
    }

    private void addSkillCard(String title, String condition, boolean unlocked, String description) {
        LinearLayout c = card();
        LinearLayout r = row();
        LinearLayout details = column();
        details.addView(text(title, 13, WHITE, true));
        details.addView(text(condition, 10, MUTED, false));
        r.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(text(unlocked ? "UNLOCKED" : "LOCKED", 9, unlocked ? GREEN : MUTED, true));
        c.addView(r);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(8); content.addView(c, p);
    }

    private void chooseClass() {
        String[] classes = {"Warrior — Physical fitness", "Mage — Science & learning", "Assassin — Speed & precision", "Healer — Health & recovery", "Strategist — Planning & reasoning"};
        new AlertDialog.Builder(this).setTitle("Choose your class").setItems(classes, (d, which) -> {
            String[] names = {"Warrior", "Mage", "Assassin", "Healer", "Strategist"};
            Store.putString(this, "player_class", names[which]); render(); toast("Class selected: " + names[which]);
        }).show();
    }

    private void addShopItem(String name, String description, int cost) {
        LinearLayout c = card();
        LinearLayout r = row();
        LinearLayout details = column();
        details.addView(text(name, 13, WHITE, true));
        details.addView(text(description + " • " + cost + " coins", 10, MUTED, false));
        r.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
        Button buy = button("BUY", 0xFF443A83, WHITE);
        buy.setOnClickListener(v -> buyItem(name, cost)); r.addView(buy);
        c.addView(r);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(8); content.addView(c, p);
    }

    private void buyItem(String name, int cost) {
        JSONArray inv = Store.readArray(this, "inventory");
        for (int i = 0; i < inv.length(); i++) if (name.equals(inv.optString(i))) { toast("Already owned"); return; }
        int coins = Store.getInt(this, "coins", 0);
        if (coins < cost) { toast("Not enough coins"); return; }
        inv.put(name); Store.saveArray(this, "inventory", inv); Store.putInt(this, "coins", coins - cost);
        render(); toast("Added to inventory");
    }

    private void spendPoint(String code) {
        int points = Store.getInt(this, "stat_points", 0);
        if (points <= 0) { toast("No available stat points"); return; }
        int score = Store.getInt(this, "stat_" + code, 5);
        Store.putInt(this, "stat_" + code, score + 1);
        Store.putInt(this, "stat_points", points - 1);
        render();
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
}
