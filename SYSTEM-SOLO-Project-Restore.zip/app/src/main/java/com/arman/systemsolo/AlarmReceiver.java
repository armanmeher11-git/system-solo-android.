package com.arman.systemsolo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "system_solo_alarms";

    @Override public void onReceive(Context context, Intent intent) {
        Store.initialise(context);
        int id = intent.getIntExtra("alarm_id", -1);
        JSONObject alarm = Store.findAlarm(context, id);
        if (alarm == null || !alarm.optBoolean("enabled", true)) return;

        showNotification(context, alarm);
        AlarmScheduler.rescheduleRepeating(context, alarm);
    }

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager.getNotificationChannel(CHANNEL_ID) != null) return;
            Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            AudioAttributes audio = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Quest alarms", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Scheduled reminders for SYSTEM: SOLO quests");
            channel.enableVibration(true);
            channel.setSound(sound, audio);
            manager.createNotificationChannel(channel);
        }
    }

    private void showNotification(Context context, JSONObject alarm) {
        createChannel(context);
        int id = alarm.optInt("id", 1);
        String title = alarm.optString("title", "Quest reminder");
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 700000 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("SYSTEM: SOLO — Reminder")
                .setContentText(title)
                .setStyle(new Notification.BigTextStyle().bigText(title + "\nYour scheduled quest is ready."))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        try { manager.notify(700000 + id, n); } catch (SecurityException ignored) { }
    }
}
